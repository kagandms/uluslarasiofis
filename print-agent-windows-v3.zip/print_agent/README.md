# Print Agent

The agent runs on the office Windows PC and applies A4/A3, portrait/landscape, monochrome/color, simplex/long-edge duplex, and the server-configured copy limits to each job. It reports settings protocol 2. Older protocol 0/1 agents remain limited to portrait jobs and at most three copies; protocol 2 is required for landscape or more than three copies. SumatraPDF is installed separately and is never stored in this repository.

Install the Python dependencies from `requirements.txt`, then configure these environment variables for the service account:

- `PRINT_AGENT_BASE_URL`: HTTPS origin of the deployed portal.
- `PRINTER_SECRET`: the machine API secret stored separately in the Worker environment.
- `PRINT_PRINTER_ID`: stable opaque identifier for this printer.
- `PRINT_RUNNER_ID`: stable opaque identifier for this agent instance.
- `PRINT_PRINTER_NAME`: exact Windows printer queue name.
- `PRINT_AGENT_SUMATRA_PATH`: absolute path to the installed `SumatraPDF.exe`.
- `PRINT_AGENT_TEMP_DIR`: private local directory for downloaded and normalized files.
- `PRINT_AGENT_POLL_SECONDS`: polling interval from 1 to 60 seconds (default 5).

Use `.env.example` as a names-only template; it is not automatically loaded. Set values for the Windows service account using the office's approved secret/configuration mechanism. Never put the real `PRINTER_SECRET` in this repository. At startup the agent checks the HTTPS origin, secret presence, stable IDs, SumatraPDF file, and writable temporary directory. Invalid configuration prevents job claims. When it can authenticate to the configured HTTPS origin, it reports an `unavailable` heartbeat until all local prerequisites and the Windows printer queue are ready.

The agent checks PDF/JPG/PNG signatures against the declared type, downloads only content that matches the expected byte count and SHA-256, and parses the file locally before sending the verified page count. PDF pages and images are normalized into centered, uncropped pages whose A4/A3 media boxes match the selected portrait or landscape orientation. The Worker and Agent enforce the configured maximum copies and page-impression budget (`verified page count × copies`); the defaults are 50 copies and 200 impressions per job. The D1 schema retains hard ceilings of 50 copies and 1,000 impressions. The per-job temporary directory is removed after processing.

SumatraPDF receives the exact server-stored options: `paper=A4` or `paper=A3`, `portrait` or `landscape`, `monochrome` or `color`, `simplex` or `duplexlong`, and the validated `<n>x` copy count. Physical orientation is also encoded in the normalized PDF page geometry, so it does not rely on Sumatra's content-rotation flag alone. The shared Windows queue defaults are never changed. The Cloudflare-compatible `TopkapiPrintAgent/1.0` User-Agent is sent on API requests. Windows printer checks fail closed when the queue entry, status payload, or required status field is missing or malformed.

For the Phase 3 foreground test, open PowerShell under the intended Windows account, configure the variables above in that session, then run:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe .\print_agent.py
```

This starts the agent in the foreground. No Windows Service is installed by these steps.

A job is durably marked `submission_started` before SumatraPDF runs. Any ambiguous result after that point is reported as `unknown`; the agent never claims or prints that job again automatically.
