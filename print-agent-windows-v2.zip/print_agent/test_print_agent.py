from __future__ import annotations

import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from PIL import Image

from print_agent import (
    AgentConfig,
    build_sumatra_print_settings,
    is_https_origin,
    print_job,
    printer_is_available,
    send_heartbeat,
    validate_document,
    validate_startup,
)


class PrintAgentTests(unittest.TestCase):
    def test_backend_address_must_be_an_https_origin(self) -> None:
        self.assertTrue(is_https_origin("https://print.example.test"))
        self.assertFalse(is_https_origin("http://print.example.test"))
        self.assertFalse(is_https_origin("https://print.example.test/path"))
        self.assertFalse(is_https_origin("https://user:pass@print.example.test"))

    def test_environment_configuration_records_invalid_url_and_missing_printer(self) -> None:
        with patch.dict("os.environ", {
            "PRINT_AGENT_BASE_URL": "http://print.example.test/path",
            "PRINTER_SECRET": "secret",
        }, clear=True):
            config = AgentConfig.from_environment()

        self.assertIn("base_url_must_be_https_origin", config.configuration_errors)
        self.assertIn("printer_id_missing_or_invalid", config.configuration_errors)
        self.assertIn("runner_id_missing_or_invalid", config.configuration_errors)
        self.assertIn("printer_name_missing_or_invalid", config.configuration_errors)

    def test_missing_sumatra_reports_unavailable_heartbeat(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.body = None

            def json(self, _path: str, body: dict[str, object]):
                self.body = body
                return {}

        api = FakeApi()
        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("missing.exe"))

        is_available = send_heartbeat(api, config, False)

        self.assertFalse(is_available)
        self.assertEqual(api.body["health"], "unavailable")
        self.assertEqual(api.body["settings_protocol"], 1)

    def test_api_requests_include_cloudflare_compatible_user_agent(self) -> None:
        class FakeResponse:
            headers = {}

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return None

            def read(self, _limit: int) -> bytes:
                return b"{}"

        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"))
        with patch("urllib.request.urlopen", return_value=FakeResponse()) as urlopen:
            from print_agent import PrintApi

            PrintApi(config).request("/api/printer/heartbeat", {})

        request = urlopen.call_args.args[0]
        self.assertEqual(request.get_header("User-agent"), "TopkapiPrintAgent/1.0")

    def test_pdf_page_count_is_read_from_the_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.pdf"
            target = Path(temporary_directory) / "ready.pdf"
            import fitz

            document = fitz.open()
            document.new_page()
            document.new_page()
            document.save(source)
            document.close()

            page_count = validate_document(source, "application/pdf", target)

        self.assertEqual(page_count, 2)

    def test_png_is_converted_to_a_single_page_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.png"
            target = Path(temporary_directory) / "ready.pdf"
            Image.new("RGB", (200, 100), "white").save(source)

            page_count = validate_document(source, "image/png", target)

            self.assertEqual(page_count, 1)
            self.assertTrue(target.is_file())
            import fitz

            with fitz.open(target) as document:
                self.assertAlmostEqual(document[0].rect.width, 595.2756, places=2)
                self.assertAlmostEqual(document[0].rect.height, 841.8898, places=2)

    def test_jpeg_conversion_uses_selected_a3_page_size(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.jpg"
            target = Path(temporary_directory) / "ready.pdf"
            Image.new("RGB", (200, 100), "white").save(source)

            page_count = validate_document(source, "image/jpeg", target, "A3")

            self.assertEqual(page_count, 1)
            import fitz

            with fitz.open(target) as document:
                self.assertAlmostEqual(document[0].rect.width, 841.8898, places=2)
                self.assertAlmostEqual(document[0].rect.height, 1190.5512, places=2)

    def test_sumatra_options_map_each_supported_setting(self) -> None:
        settings = build_sumatra_print_settings({
            "paper_size": "A3", "color_mode": "color", "duplex": "duplexlong", "copies": 3,
        })

        self.assertEqual(settings, "paper=A3,color,duplexlong,fit,3x,ignore-pdf-print-settings")

    def test_sumatra_options_reject_unsupported_or_modified_settings(self) -> None:
        valid_job = {"paper_size": "A4", "color_mode": "monochrome", "duplex": "simplex", "copies": 1}
        invalid_jobs = (
            {**valid_job, "paper_size": "LETTER"},
            {**valid_job, "color_mode": "auto"},
            {**valid_job, "duplex": "duplex"},
            {**valid_job, "copies": True},
            {**valid_job, "copies": 0},
        )

        for job in invalid_jobs:
            with self.subTest(job=job), self.assertRaises(ValueError):
                build_sumatra_print_settings(job)

    def test_declared_format_must_match_file_signature(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.png"
            target = Path(temporary_directory) / "ready.pdf"
            source.write_bytes(b"%PDF-not-a-png")

            with self.assertRaisesRegex(ValueError, "signature"):
                validate_document(source, "image/png", target)

    def test_startup_requires_sumatra_and_writable_temp_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office",
                                 Path(temporary_directory) / "missing.exe", Path(temporary_directory) / "temp")

            errors = validate_startup(config)

        self.assertEqual(errors, ("sumatra_executable_missing",))

    def test_sumatra_failure_after_submission_lock_is_marked_unknown(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, object]]] = []

            def request(self, path: str, body=None, headers=None):
                import hashlib

                payload = b"%PDF-test"
                return payload, {"X-Content-SHA256": hashlib.sha256(payload).hexdigest()}

            def json(self, path: str, body=None, headers=None):
                self.calls.append((path, body or {}))
                return {}

        api = FakeApi()
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "printable.pdf"
            import fitz

            document = fitz.open()
            document.new_page()
            document.save(source)
            document.close()
            job = {"id": "job1", "lease_token": "lease", "media_type": "application/pdf", "byte_size": source.stat().st_size,
                   "paper_size": "A4", "color_mode": "monochrome", "duplex": "simplex", "copies": 1}
            config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"),
                                 Path(temporary_directory))

            with patch("print_agent.download_job", side_effect=lambda _api, _job, target: target.write_bytes(source.read_bytes())), \
                    patch("print_agent.subprocess.run", side_effect=TimeoutError()) as run_sumatra:
                print_job(api, config, job)

        self.assertTrue(any(path.endswith("submission-started") for path, _ in api.calls))
        self.assertEqual(api.calls[-1][1]["status"], "unknown")
        self.assertIn("paper=A4,monochrome,simplex,fit,1x,ignore-pdf-print-settings",
                      run_sumatra.call_args.args[0])

    def test_invalid_copy_count_is_rejected_before_download_or_submission(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, object]]] = []

            def json(self, path: str, body=None, headers=None):
                self.calls.append((path, body or {}))
                return {}

        api = FakeApi()
        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"))
        job = {"id": "job1", "lease_token": "lease", "media_type": "application/pdf", "paper_size": "A4",
               "color_mode": "monochrome", "duplex": "simplex", "copies": 4}

        print_job(api, config, job)

        self.assertEqual(api.calls[0][1]["result_code"], "invalid_print_options")
        self.assertFalse(any(path.endswith("submission-started") for path, _ in api.calls))

    def test_missing_claim_setting_is_rejected_before_download_or_submission(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, object]]] = []

            def json(self, path: str, body=None, headers=None):
                self.calls.append((path, body or {}))
                return {}

        api = FakeApi()
        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"))
        job = {"id": "job1", "lease_token": "lease", "media_type": "application/pdf", "copies": 1,
               "paper_size": "A4", "color_mode": "monochrome"}

        print_job(api, config, job)

        self.assertEqual(api.calls[0][1]["result_code"], "invalid_print_options")
        self.assertFalse(any(path.endswith("submission-started") for path, _ in api.calls))

    @staticmethod
    def _create_mock_win32print(printer_name: str = "Office Printer", status: int = 0, enum_entries=None):
        fake = types.ModuleType("win32print")
        fake.PRINTER_ENUM_LOCAL = 2
        fake.PRINTER_ENUM_CONNECTIONS = 4
        fake.PRINTER_STATUS_ERROR = 0x2
        fake.PRINTER_STATUS_OFFLINE = 0x80
        fake.PRINTER_STATUS_NOT_AVAILABLE = 0x1000
        fake.PRINTER_STATUS_PAPER_OUT = 0x10
        fake.PRINTER_STATUS_PAUSED = 0x1
        fake.PRINTER_STATUS_PENDING_DELETION = 0x4
        if enum_entries is None:
            enum_entries = ({"pPrinterName": printer_name},)
        fake.EnumPrinters = MagicMock(return_value=enum_entries)
        fake.OpenPrinter = MagicMock(return_value=123)
        fake.GetPrinter = MagicMock(return_value={"Status": status})
        fake.ClosePrinter = MagicMock()
        return fake

    def test_printer_is_available_with_level_2_dict_and_ready_status(self) -> None:
        fake_win32print = self._create_mock_win32print("Office Printer", status=0)
        with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
            self.assertTrue(printer_is_available("Office Printer"))
            fake_win32print.ClosePrinter.assert_called_once_with(123)

    def test_printer_is_available_returns_false_when_printer_not_found(self) -> None:
        fake_win32print = self._create_mock_win32print("Office Printer", status=0)
        with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
            self.assertFalse(printer_is_available("Nonexistent Printer"))
            fake_win32print.OpenPrinter.assert_not_called()

    def test_printer_is_available_returns_false_when_printer_is_offline(self) -> None:
        fake_win32print = self._create_mock_win32print("Office Printer", status=0x80)
        with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
            self.assertFalse(printer_is_available("Office Printer"))
            fake_win32print.ClosePrinter.assert_called_once_with(123)

    def test_printer_is_available_safely_handles_malformed_enum_entries(self) -> None:
        malformed_entries = ({}, None, {"pPrinterName": 123}, {"pPrinterName": "Office Printer"})
        fake_win32print = self._create_mock_win32print(enum_entries=malformed_entries, status=0)
        with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
            self.assertTrue(printer_is_available("Office Printer"))
            self.assertFalse(printer_is_available("Missing Printer"))

    def test_printer_is_available_returns_false_when_get_printer_returns_non_dict(self) -> None:
        fake_win32print = self._create_mock_win32print("Office Printer", status=0)
        fake_win32print.GetPrinter = MagicMock(return_value="unexpected_string_result")
        with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
            self.assertFalse(printer_is_available("Office Printer"))
            fake_win32print.ClosePrinter.assert_called_once_with(123)

    def test_printer_is_available_returns_false_when_get_printer_status_is_invalid(self) -> None:
        for invalid_status in ("not_an_int", None, []):
            with self.subTest(invalid_status=invalid_status):
                fake_win32print = self._create_mock_win32print("Office Printer", status=0)
                fake_win32print.GetPrinter = MagicMock(return_value={"Status": invalid_status})
                with patch("os.name", "nt"), patch.dict("sys.modules", {"win32print": fake_win32print}):
                    self.assertFalse(printer_is_available("Office Printer"))
                    fake_win32print.ClosePrinter.assert_called_once_with(123)


if __name__ == "__main__":
    unittest.main()
