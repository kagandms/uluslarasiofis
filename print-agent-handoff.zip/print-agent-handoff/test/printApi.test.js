import assert from 'node:assert/strict';
import { test } from 'node:test';
import worker from '../src/server/worker.js';
import { createPrintRepository } from '../src/server/repositories/d1/printRepository.js';
import { applyAllMigrations } from './helpers/apply-migrations.js';
import { TestD1Database } from './helpers/d1-test-binding.js';

const PRINTER_SECRET = 'A'.repeat(48);

function createEnvironment() {
    const database = new TestD1Database();
    applyAllMigrations(database);
    const objects = new Map();
    const bucket = {
        async head(key) {
            const object = objects.get(key);
            return object ? { key, size: object.size, etag: object.etag, httpMetadata: { contentType: object.type } } : null;
        },
        async get(key) { return objects.get(key) || null; },
        async delete(key) { objects.delete(key); }
    };
    return {
        database, objects,
        environment: {
            DB: database, PRINT_FILES: bucket, PRINT_BUCKET_NAME: 'test-print',
            R2_ACCOUNT_ID: 'account', PRINT_R2_ACCESS_KEY_ID: 'access', PRINT_R2_SECRET_ACCESS_KEY: 'secret',
            PRINTER_SECRET, STAFF_SHARED_USERNAME: 'admin', APP_ENV: 'test'
        }
    };
}

function request(path, { method = 'GET', body, headers = {} } = {}) {
    const requestHeaders = new Headers({ 'CF-Connecting-IP': '198.51.100.20', Origin: 'https://portal.test', ...headers });
    if (body !== undefined) requestHeaders.set('Content-Type', 'application/json');
    return new Request(`https://portal.test${path}`, {
        method, headers: requestHeaders, body: body === undefined ? undefined : JSON.stringify(body)
    });
}

function printerHeaders(secret = PRINTER_SECRET, extra = {}) {
    return { Authorization: `Bearer ${secret}`, ...extra };
}

test('public print upload, machine validation, page count, and status follow the constrained job lifecycle', async () => {
    const { environment, database, objects } = createEnvironment();
    const repository = createPrintRepository(database);
    await repository.heartbeat({ printerId: 'office-printer', runnerId: 'runner-1', health: 'ready',
        printerName: 'Office Printer', now: new Date().toISOString() });
    const pdf = new Uint8Array([37, 80, 68, 70, 45, 49, 46, 55]);
    const tokens = { idempotency_key: 'a'.repeat(64), tracking_token: 'b'.repeat(64), upload_token: 'c'.repeat(64) };
    const intentResponse = await worker.fetch(request('/api/public/print/upload-intents', {
        method: 'POST', body: { byte_size: pdf.length, copies: 2, media_type: 'application/pdf', ...tokens }
    }), environment);
    assert.equal(intentResponse.status, 200);
    const intent = await intentResponse.json();
    assert.equal(intent.status, 'uploading');
    assert.equal(intent.upload.method, 'PUT');
    assert.equal(intent.job_id.includes('.pdf'), false);
    const uploadJob = database.prepare('SELECT storage_key FROM print_jobs WHERE id=?').bind(intent.job_id).first();
    objects.set(uploadJob.storage_key, new Blob([pdf], { type: 'application/pdf' }));
    const finalizeResponse = await worker.fetch(request(`/api/public/print/jobs/${intent.job_id}/finalize`, {
        method: 'POST', headers: { 'X-Print-Upload-Token': tokens.upload_token }
    }), environment);
    assert.equal(finalizeResponse.status, 200);
    assert.equal(database.prepare('SELECT page_count FROM print_jobs WHERE id=?').bind(intent.job_id).first().page_count, null);

    const claimResponse = await worker.fetch(request('/api/printer/claim', {
        method: 'POST', body: { runner_id: 'runner-1' }, headers: printerHeaders()
    }), environment);
    assert.equal(claimResponse.status, 200);
    const claimed = (await claimResponse.json()).job;
    assert.equal(claimed.copies, 2);
    const leaseHeader = { 'X-Print-Lease': claimed.lease_token };
    const validationResponse = await worker.fetch(request(`/api/printer/jobs/${intent.job_id}/validation-result`, {
        method: 'POST', body: { status: 'ready', page_count: 2 }, headers: printerHeaders(PRINTER_SECRET, leaseHeader)
    }), environment);
    assert.equal(validationResponse.status, 200);
    assert.equal(database.prepare('SELECT page_count FROM print_jobs WHERE id=?').bind(intent.job_id).first().page_count, 2);

    const statusResponse = await worker.fetch(request('/api/public/print/jobs/status', {
        headers: { 'X-Print-Tracking-Token': tokens.tracking_token }
    }), environment);
    assert.equal(statusResponse.status, 200);
    assert.equal((await statusResponse.json()).status, 'ready');
    const isolatedResponse = await worker.fetch(request('/api/public/print/jobs/status', {
        headers: { 'X-Print-Tracking-Token': 'd'.repeat(64) }
    }), environment);
    assert.equal(isolatedResponse.status, 404);
});

test('printer machine endpoints reject absent and invalid secrets', async () => {
    const { environment } = createEnvironment();
    for (const secret of ['', 'wrong']) {
        const response = await worker.fetch(request('/api/printer/claim', {
            method: 'POST', body: { runner_id: 'runner-1' }, headers: printerHeaders(secret)
        }), environment);
        assert.equal(response.status, 401);
    }
});

test('public availability stays false when the isolated print bucket is not configured', async () => {
    const { environment, database } = createEnvironment();
    await createPrintRepository(database).heartbeat({ printerId: 'office-printer', runnerId: 'runner-1', health: 'ready',
        printerName: 'Office Printer', now: new Date().toISOString() });
    delete environment.PRINT_R2_SECRET_ACCESS_KEY;

    const response = await worker.fetch(request('/api/public/print/status'), environment);

    assert.equal(response.status, 200);
    assert.equal((await response.json()).available, false);
});
