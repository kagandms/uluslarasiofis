# Print Agent Handoff Package

This package contains the Python Print Agent and the print-specific portal source needed to understand its staging API contract. It is prepared from the local `production` worktree. No deployment or source edits were made to prepare it.

## Windows foreground installation

1. Install Python 3.12 (64-bit) and install SumatraPDF separately on the school PC. Do not copy a SumatraPDF binary from this archive; the agent requires its configured executable path.
2. Open PowerShell in the extracted `print-agent-handoff` folder and install the agent dependencies:

   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r scripts\print_agent\requirements.txt
   ```

3. Configure the environment variables listed in `scripts/print_agent/README.md` for that PowerShell session or the approved Windows account configuration. `.env.example` contains only a placeholder and is not loaded by the agent. Never use a real secret in a command that echoes it, a source file, or a log.
4. Set `PRINT_AGENT_BASE_URL` to `https://goc-staging.topkapiuni.workers.dev` for this UAT, and set `PRINT_AGENT_SUMATRA_PATH` to the installed `SumatraPDF.exe` path.
5. Start in the foreground (no Windows Service):

   ```powershell
   .\.venv\Scripts\python.exe .\scripts\print_agent\print_agent.py
   ```

The agent checks startup configuration, the Sumatra executable, the temporary directory, and printer queue health before reporting `ready`. The fixed print policy is PDF/JPG/PNG, A4, monochrome, simplex, and 1–3 copies. Parsed page count is reported by the agent only after local parsing. After `submission_started`, ambiguous outcomes become `unknown` and are not automatically retried.

## Phase 3 physical UAT sequence

Use only synthetic test documents. In order, validate foreground startup; staging heartbeat and public availability; one-page synthetic PDF; actual physical output; JPG; PNG; 1/2/3 copies; printer offline/recovery; agent stop/restart; network failure before print; and connection loss after `submission_started` with duplicate-print observation. Do not use student documents, production, QR changes, ClamAV, or Windows Service installation in this UAT.

The staging scheduled print-cleanup cron invocation is a known open issue. It does not stop physical UAT, but it must be resolved before production. Manually clean up synthetic staging print jobs and objects as needed after each run.

## Package map

- `scripts/print_agent/`: standalone Python agent, requirements, tests, README, and placeholder-only configuration example.
- `src/server/`: print API routes, policy, D1 repository, print-only R2 storage, cleanup service, and Worker route/scheduled dispatch context.
- `src/public/` and `yazdir/`: student print upload UI and its entry page.
- `test/` and `scripts/print_agent/test_print_agent.py`: print backend and agent tests.
- `migrations/0011_print_queue.sql`: print queue schema.
- `docs/print-staging-r2-cors.json`: staging print bucket CORS policy.

The Python agent can be installed independently using its requirements file. Running the included backend tests requires the full portal repository and its Node dependencies; this handoff archive does not include the rest of the application, `.git`, `node_modules`, credentials, or build output.
