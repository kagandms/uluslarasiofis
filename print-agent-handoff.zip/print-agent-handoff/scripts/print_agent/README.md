# Print Agent

The agent runs on the office Windows PC and sends only fixed A4, monochrome, simplex jobs to the configured Windows printer. It uses the configured SumatraPDF executable for silent spooler submission; the executable is installed separately and is never stored in this repository.

Install the Python dependencies from `requirements.txt`, then configure these environment variables for the service account:

- `PRINT_AGENT_BASE_URL`: HTTPS origin of the deployed portal.
- `PRINTER_SECRET`: the machine API secret stored separately in the Worker environment.
- `PRINT_PRINTER_ID`: stable opaque identifier for this printer.
- `PRINT_RUNNER_ID`: stable opaque identifier for this agent instance.
- `PRINT_PRINTER_NAME`: exact Windows printer queue name.
- `PRINT_AGENT_SUMATRA_PATH`: absolute path to the installed `SumatraPDF.exe`.
- `PRINT_AGENT_TEMP_DIR`: private local directory for downloaded and normalized files.
- `PRINT_AGENT_POLL_SECONDS`: polling interval from 1 to 60 seconds (default 5).

Use `.env.example` as a names-only template; it is not automatically loaded. Set values for the Windows service account using the office's approved secret/configuration mechanism. Never put the real `PRINTER_SECRET` in this repository. At startup the agent checks the HTTPS origin, secret presence, stable IDs, SumatraPDF file, and writable temporary directory. Invalid configuration prevents job claims. When it can authenticate to the configured HTTPS origin, it reports an `unavailable` heartbeat until all local prerequisites and the Windows printer queue are ready.

The agent checks PDF/JPG/PNG signatures against the declared type, downloads only content that matches the expected byte count and SHA-256, and parses the file locally before sending the verified page count. Image files are normalized to a centered, single-page A4 PDF. PDF page counts are derived from the parsed document. The per-job temporary directory is removed after processing.

Only integer copy counts from 1 through 3 are accepted. SumatraPDF receives fixed A4, monochrome, simplex settings.

For the Phase 3 foreground test, open PowerShell under the intended Windows account, configure the variables above in that session, then run:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe .\print_agent.py
```

This starts the agent in the foreground. No Windows Service is installed by these steps.

A job is durably marked `submission_started` before SumatraPDF runs. Any ambiguous result after that point is reported as `unknown`; the agent never claims or prints that job again automatically.
