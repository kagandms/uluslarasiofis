from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from print_agent import AgentConfig, is_https_origin, print_job, send_heartbeat, validate_document, validate_startup


class PrintAgentTests(unittest.TestCase):
    def test_backend_address_must_be_an_https_origin(self) -> None:
        self.assertTrue(is_https_origin("https://print.example.test"))
        self.assertFalse(is_https_origin("http://print.example.test"))
        self.assertFalse(is_https_origin("https://print.example.test/path"))
        self.assertFalse(is_https_origin("https://user:pass@print.example.test"))

    def test_environment_configuration_records_invalid_url_and_missing_printer(self) -> None:
        with patch.dict("os.environ", {
            "PRINT_AGENT_BASE_URL": "http://print.example.test/path",
            "PRINTER_SECRET": "secret",
        }, clear=True):
            config = AgentConfig.from_environment()

        self.assertIn("base_url_must_be_https_origin", config.configuration_errors)
        self.assertIn("printer_id_missing_or_invalid", config.configuration_errors)
        self.assertIn("runner_id_missing_or_invalid", config.configuration_errors)
        self.assertIn("printer_name_missing_or_invalid", config.configuration_errors)

    def test_missing_sumatra_reports_unavailable_heartbeat(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.body = None

            def json(self, _path: str, body: dict[str, object]):
                self.body = body
                return {}

        api = FakeApi()
        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("missing.exe"))

        is_available = send_heartbeat(api, config, False)

        self.assertFalse(is_available)
        self.assertEqual(api.body["health"], "unavailable")

    def test_pdf_page_count_is_read_from_the_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.pdf"
            target = Path(temporary_directory) / "ready.pdf"
            import fitz

            document = fitz.open()
            document.new_page()
            document.new_page()
            document.save(source)
            document.close()

            page_count = validate_document(source, "application/pdf", target)

        self.assertEqual(page_count, 2)

    def test_png_is_converted_to_a_single_page_pdf(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.png"
            target = Path(temporary_directory) / "ready.pdf"
            Image.new("RGB", (200, 100), "white").save(source)

            page_count = validate_document(source, "image/png", target)

            self.assertEqual(page_count, 1)
            self.assertTrue(target.is_file())
            import fitz

            with fitz.open(target) as document:
                self.assertAlmostEqual(document[0].rect.width, 595.2756, places=2)
                self.assertAlmostEqual(document[0].rect.height, 841.8898, places=2)

    def test_declared_format_must_match_file_signature(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "source.png"
            target = Path(temporary_directory) / "ready.pdf"
            source.write_bytes(b"%PDF-not-a-png")

            with self.assertRaisesRegex(ValueError, "signature"):
                validate_document(source, "image/png", target)

    def test_startup_requires_sumatra_and_writable_temp_directory(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office",
                                 Path(temporary_directory) / "missing.exe", Path(temporary_directory) / "temp")

            errors = validate_startup(config)

        self.assertEqual(errors, ("sumatra_executable_missing",))

    def test_sumatra_failure_after_submission_lock_is_marked_unknown(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, object]]] = []

            def request(self, path: str, body=None, headers=None):
                import hashlib

                payload = b"%PDF-test"
                return payload, {"X-Content-SHA256": hashlib.sha256(payload).hexdigest()}

            def json(self, path: str, body=None, headers=None):
                self.calls.append((path, body or {}))
                return {}

        api = FakeApi()
        with tempfile.TemporaryDirectory() as temporary_directory:
            source = Path(temporary_directory) / "printable.pdf"
            import fitz

            document = fitz.open()
            document.new_page()
            document.save(source)
            document.close()
            job = {"id": "job1", "lease_token": "lease", "media_type": "application/pdf", "byte_size": source.stat().st_size,
                   "copies": 1}
            config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"),
                                 Path(temporary_directory))

            with patch("print_agent.download_job", side_effect=lambda _api, _job, target: target.write_bytes(source.read_bytes())), \
                    patch("print_agent.subprocess.run", side_effect=TimeoutError()):
                print_job(api, config, job)

        self.assertTrue(any(path.endswith("submission-started") for path, _ in api.calls))
        self.assertEqual(api.calls[-1][1]["status"], "unknown")

    def test_invalid_copy_count_is_rejected_before_download_or_submission(self) -> None:
        class FakeApi:
            def __init__(self) -> None:
                self.calls: list[tuple[str, dict[str, object]]] = []

            def json(self, path: str, body=None, headers=None):
                self.calls.append((path, body or {}))
                return {}

        api = FakeApi()
        config = AgentConfig("https://example.test", "secret", "printer", "runner", "Office", Path("sumatra.exe"))
        job = {"id": "job1", "lease_token": "lease", "media_type": "application/pdf", "copies": 4}

        print_job(api, config, job)

        self.assertEqual(api.calls[0][1]["result_code"], "invalid_print_options")
        self.assertFalse(any(path.endswith("submission-started") for path, _ in api.calls))


if __name__ == "__main__":
    unittest.main()
