from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import re
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import fitz
from PIL import Image, ImageOps

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_PAGE_COUNT = 20
HEARTBEAT_SECONDS = 20
POLL_SECONDS = 5
REQUEST_TIMEOUT_SECONDS = 30
DEFAULT_AGENT_TEMP_DIR = Path(tempfile.gettempdir()) / "topkapi-print-agent"
A4_WIDTH_POINTS = 595.2756
A4_HEIGHT_POINTS = 841.8898


def is_https_origin(value: str) -> bool:
    try:
        parsed = urlsplit(value)
        return (parsed.scheme == "https" and bool(parsed.hostname) and parsed.username is None
                and parsed.password is None and parsed.path in {"", "/"} and not parsed.query
                and not parsed.fragment and (parsed.port is None or 1 <= parsed.port <= 65535))
    except ValueError:
        return False


@dataclass(frozen=True)
class AgentConfig:
    base_url: str
    secret: str
    printer_id: str
    runner_id: str
    printer_name: str
    sumatra_path: Path
    temp_directory: Path = DEFAULT_AGENT_TEMP_DIR
    poll_seconds: int = POLL_SECONDS
    configuration_errors: tuple[str, ...] = ()

    @classmethod
    def from_environment(cls) -> AgentConfig:
        base_url = os.environ.get("PRINT_AGENT_BASE_URL", "").rstrip("/")
        secret = os.environ.get("PRINTER_SECRET", "")
        printer_id = os.environ.get("PRINT_PRINTER_ID", "unconfigured-printer")
        runner_id = os.environ.get("PRINT_RUNNER_ID", "unconfigured-runner")
        printer_name = os.environ.get("PRINT_PRINTER_NAME", "")
        sumatra_path = Path(os.environ.get("PRINT_AGENT_SUMATRA_PATH", ""))
        temp_directory = Path(os.environ.get("PRINT_AGENT_TEMP_DIR", str(DEFAULT_AGENT_TEMP_DIR)))
        errors: list[str] = []
        if not is_https_origin(base_url):
            errors.append("base_url_must_be_https_origin")
        if not secret:
            errors.append("printer_secret_missing")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", printer_id) or printer_id == "unconfigured-printer":
            errors.append("printer_id_missing_or_invalid")
            printer_id = "unconfigured-printer"
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", runner_id) or runner_id == "unconfigured-runner":
            errors.append("runner_id_missing_or_invalid")
            runner_id = "unconfigured-runner"
        if (not printer_name.strip() or len(printer_name) > 128
                or any(ord(character) < 32 for character in printer_name)):
            errors.append("printer_name_missing_or_invalid")
            printer_name = "Unconfigured printer"
        raw_poll_seconds = os.environ.get("PRINT_AGENT_POLL_SECONDS", str(POLL_SECONDS))
        try:
            poll_seconds = int(raw_poll_seconds)
            if not 1 <= poll_seconds <= 60:
                raise ValueError
        except ValueError:
            errors.append("poll_seconds_invalid")
            poll_seconds = POLL_SECONDS
        return cls(base_url, secret, printer_id, runner_id, printer_name, sumatra_path,
                   temp_directory, poll_seconds, tuple(errors))


class PrintApi:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config

    def request(self, path: str, body: dict[str, Any] | None = None,
                headers: dict[str, str] | None = None) -> tuple[bytes, dict[str, str]]:
        request_headers = {"Authorization": f"Bearer {self.config.secret}", **(headers or {})}
        payload = None
        if body is not None:
            payload = json.dumps(body, separators=(",", ":")).encode("utf-8")
            request_headers["Content-Type"] = "application/json"
        method = "POST" if body is not None else "GET"
        request = urllib.request.Request(self.config.base_url + path, data=payload, headers=request_headers, method=method)
        with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            return response.read(MAX_FILE_BYTES + 1024), dict(response.headers.items())

    def json(self, path: str, body: dict[str, Any] | None = None,
             headers: dict[str, str] | None = None) -> dict[str, Any]:
        response, _ = self.request(path, body, headers)
        return json.loads(response)


def image_to_pdf(source: Path, target: Path) -> int:
    with Image.open(source) as image:
        image.verify()
    with Image.open(source) as image:
        oriented = ImageOps.exif_transpose(image).convert("RGB")
        if oriented.width * oriented.height > 40_000_000:
            raise ValueError("Image pixel count exceeds the configured limit.")
        with fitz.open() as document:
            page = document.new_page(width=A4_WIDTH_POINTS, height=A4_HEIGHT_POINTS)
            scale = min(page.rect.width / oriented.width, page.rect.height / oriented.height)
            width = oriented.width * scale
            height = oriented.height * scale
            image_rect = fitz.Rect((page.rect.width - width) / 2, (page.rect.height - height) / 2,
                                   (page.rect.width + width) / 2, (page.rect.height + height) / 2)
            with io.BytesIO() as image_bytes:
                oriented.save(image_bytes, format="PNG")
                page.insert_image(image_rect, stream=image_bytes.getvalue())
            document.save(target)
    return 1


def has_expected_signature(source: Path, media_type: str) -> bool:
    with source.open("rb") as file_handle:
        signature = file_handle.read(8)
    signatures = {
        "application/pdf": lambda value: value.startswith(b"%PDF-"),
        "image/jpeg": lambda value: value.startswith(b"\xff\xd8\xff"),
        "image/png": lambda value: value.startswith(b"\x89PNG\r\n\x1a\n"),
    }
    validator = signatures.get(media_type)
    return validator is not None and validator(signature)


def validate_document(source: Path, media_type: str, target_pdf: Path) -> int:
    if source.stat().st_size > MAX_FILE_BYTES:
        raise ValueError("Print file exceeds the configured size limit.")
    if not has_expected_signature(source, media_type):
        raise ValueError("Print file signature does not match the declared format.")
    if media_type == "application/pdf":
        with fitz.open(source) as document:
            if document.is_encrypted or document.is_repaired:
                raise ValueError("PDF cannot be safely parsed for printing.")
            page_count = document.page_count
            if page_count < 1 or page_count > MAX_PAGE_COUNT:
                raise ValueError("PDF page count is outside the allowed range.")
        source.replace(target_pdf)
        return page_count
    if media_type in {"image/jpeg", "image/png"}:
        page_count = image_to_pdf(source, target_pdf)
        if page_count > MAX_PAGE_COUNT:
            raise ValueError("Image page count is outside the allowed range.")
        return page_count
    raise ValueError("Print media type is unsupported.")


def printer_is_available(printer_name: str) -> bool:
    if os.name != "nt":
        return False
    try:
        import win32print

        printer_names = {entry[2] for entry in win32print.EnumPrinters(
            win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS, None, 2
        )}
        if printer_name not in printer_names:
            return False
        handle = win32print.OpenPrinter(printer_name)
        try:
            status = win32print.GetPrinter(handle, 2).get("Status", 0)
            unavailable_statuses = (win32print.PRINTER_STATUS_ERROR | win32print.PRINTER_STATUS_OFFLINE
                                    | win32print.PRINTER_STATUS_NOT_AVAILABLE | win32print.PRINTER_STATUS_PAPER_OUT
                                    | win32print.PRINTER_STATUS_PAUSED | win32print.PRINTER_STATUS_PENDING_DELETION)
            return not bool(status & unavailable_statuses)
        finally:
            win32print.ClosePrinter(handle)
    except (ImportError, OSError, RuntimeError):
        return False


def send_heartbeat(api: PrintApi, config: AgentConfig, has_executable: bool) -> bool:
    is_available = has_executable and printer_is_available(config.printer_name)
    api.json("/api/printer/heartbeat", {
        "health": "ready" if is_available else "unavailable",
        "printer_id": config.printer_id,
        "printer_name": config.printer_name,
        "runner_id": config.runner_id,
    })
    return is_available


def validate_startup(config: AgentConfig) -> tuple[str, ...]:
    errors = list(config.configuration_errors)
    if not config.sumatra_path.is_file():
        errors.append("sumatra_executable_missing")
    try:
        config.temp_directory.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=config.temp_directory):
            pass
    except OSError:
        errors.append("temporary_directory_unavailable")
    return tuple(errors)


def post_job_result(api: PrintApi, job: dict[str, Any], result: dict[str, Any]) -> None:
    api.json(f"/api/printer/jobs/{job['id']}/result", result,
             {"X-Print-Lease": job["lease_token"]})


def download_job(api: PrintApi, job: dict[str, Any], destination: Path) -> str:
    response, headers = api.request(f"/api/printer/jobs/{job['id']}/content", headers={"X-Print-Lease": job["lease_token"]})
    expected_hash = headers.get("X-Content-SHA256", "")
    actual_hash = hashlib.sha256(response).hexdigest()
    if len(response) != job["byte_size"] or actual_hash != expected_hash:
        raise ValueError("Print content integrity check failed.")
    destination.write_bytes(response)
    return actual_hash


def report_validation_ready(api: PrintApi, job: dict[str, Any], page_count: int) -> None:
    api.json(f"/api/printer/jobs/{job['id']}/validation-result", {"status": "ready", "page_count": page_count},
             {"X-Print-Lease": job["lease_token"]})


def report_validation_failure(api: PrintApi, job: dict[str, Any], result_code: str) -> None:
    api.json(f"/api/printer/jobs/{job['id']}/validation-result", {"status": "failed", "result_code": result_code},
             {"X-Print-Lease": job["lease_token"]})


def print_job(api: PrintApi, config: AgentConfig, job: dict[str, Any]) -> None:
    copies = job.get("copies")
    if type(copies) is not int or not 1 <= copies <= 3:
        report_validation_failure(api, job, "invalid_print_options")
        return
    suffix = {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png"}.get(job["media_type"])
    if suffix is None:
        report_validation_failure(api, job, "unsupported_content")
        return
    with tempfile.TemporaryDirectory(prefix="topkapi-print-", dir=config.temp_directory) as temporary_directory:
        folder = Path(temporary_directory)
        downloaded = folder / f"source{suffix}"
        printable = folder / "document.pdf"
        try:
            download_job(api, job, downloaded)
            page_count = validate_document(downloaded, job["media_type"], printable)
        except (OSError, ValueError, fitz.FileDataError, fitz.EmptyFileError, Image.DecompressionBombError):
            report_validation_failure(api, job, "validation_failed")
            return
        report_validation_ready(api, job, page_count)
        api.json(f"/api/printer/jobs/{job['id']}/submission-started", {},
                 {"X-Print-Lease": job["lease_token"]})
        settings = f"paper=A4,monochrome,simplex,fit,{job['copies']}x,ignore-pdf-print-settings"
        command = [str(config.sumatra_path), "-print-to", config.printer_name, "-print-settings", settings,
                   "-silent", str(printable)]
        try:
            completed = subprocess.run(command, check=False, timeout=120, capture_output=True)
        except (OSError, subprocess.TimeoutExpired):
            post_job_result(api, job, {"status": "unknown", "result_code": "submission_unknown", "spooler_job_id": None})
            return
        if completed.returncode == 0:
            post_job_result(api, job, {"status": "submitted", "result_code": "submitted", "spooler_job_id": None})
            return
        post_job_result(api, job, {"status": "unknown", "result_code": "submission_unknown", "spooler_job_id": None})


def run_agent(config: AgentConfig) -> None:
    api = PrintApi(config)
    has_executable = config.sumatra_path.is_file()
    startup_errors = validate_startup(config)
    can_report_health = bool(config.secret and is_https_origin(config.base_url))
    if startup_errors:
        logging.error("Print Agent startup unavailable: %s", ",".join(startup_errors))
    if not can_report_health:
        logging.error("Print Agent cannot report unavailable health without an HTTPS URL and secret.")
        return
    next_heartbeat = 0.0
    while True:
        try:
            if time.monotonic() >= next_heartbeat:
                is_available = send_heartbeat(api, config, has_executable and not startup_errors)
                if not is_available:
                    time.sleep(HEARTBEAT_SECONDS)
                    next_heartbeat = time.monotonic() + HEARTBEAT_SECONDS
                    continue
                next_heartbeat = time.monotonic() + HEARTBEAT_SECONDS
            claim = api.json("/api/printer/claim", {"runner_id": config.runner_id})
            job = claim.get("job")
            if job:
                print_job(api, config, job)
                continue
        except (urllib.error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError) as error:
            logging.warning("Print Agent request failed: %s", type(error).__name__)
            time.sleep(min(POLL_SECONDS * 2, HEARTBEAT_SECONDS))
        time.sleep(config.poll_seconds)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    config = AgentConfig.from_environment()
    run_agent(config)


if __name__ == "__main__":
    main()
