import { ApiError } from './errors.js';

export const MAX_PRINT_BYTES = 10 * 1024 * 1024;
export const MAX_PRINT_PAGES = 20;
export const MAX_PRINT_COPIES = 3;
export const MAX_PENDING_PRINT_JOBS = 50;
export const PRINT_HEARTBEAT_MAX_AGE_MS = 60_000;
export const PRINT_UPLOAD_TTL_MS = 10 * 60_000;
export const PRINT_SUCCESS_RETENTION_MS = 15 * 60_000;
export const PRINT_FAILURE_RETENTION_MS = 60 * 60_000;
export const PRINT_ROW_RETENTION_MS = 24 * 60 * 60_000;
export const PRINT_MAX_ATTEMPTS = 3;
export const PRINT_LEASE_MS = 5 * 60_000;

const ALLOWED_MEDIA_TYPES = new Set(['application/pdf', 'image/jpeg', 'image/png']);
const RESULT_CODES = new Set(['submitted', 'printer_unavailable', 'validation_failed', 'unsupported_content', 'invalid_print_options', 'spooler_error', 'submission_unknown']);

export function validatePrintUpload(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw invalidPrintInput();
    if (!ALLOWED_MEDIA_TYPES.has(input.media_type)) throw new ApiError(415, 'PRINT_UNSUPPORTED_MEDIA', 'PDF, JPG veya PNG dosyası seçin.');
    if (!Number.isSafeInteger(input.byte_size) || input.byte_size < 1 || input.byte_size > MAX_PRINT_BYTES) {
        throw new ApiError(413, 'PRINT_FILE_SIZE_INVALID', 'Dosya boyutu izin verilen sınırı aşıyor.');
    }
    if (!Number.isSafeInteger(input.copies) || input.copies < 1 || input.copies > MAX_PRINT_COPIES) {
        throw invalidPrintInput();
    }
    return Object.freeze({ mediaType: input.media_type, byteSize: input.byte_size, copies: input.copies });
}

export function validatePrintMagicBytes(mediaType, bytes) {
    if (!(bytes instanceof Uint8Array)) return false;
    if (mediaType === 'application/pdf') return new TextDecoder().decode(bytes.subarray(0, 5)) === '%PDF-';
    if (mediaType === 'image/jpeg') return bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    if (mediaType === 'image/png') return bytes.length >= 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((byte, index) => bytes[index] === byte);
    return false;
}

export function validatePrintResult(input) {
    if (!input || typeof input !== 'object' || !['submitted', 'failed', 'unknown'].includes(input.status)
        || !RESULT_CODES.has(input.result_code)) throw invalidPrintInput();
    if (input.status === 'submitted' && input.result_code !== 'submitted') throw invalidPrintInput();
    if (input.status === 'unknown' && input.result_code !== 'submission_unknown') throw invalidPrintInput();
    if (input.spooler_job_id !== null && !(typeof input.spooler_job_id === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(input.spooler_job_id))) {
        throw invalidPrintInput();
    }
    return Object.freeze({ status: input.status, resultCode: input.result_code, spoolerJobId: input.spooler_job_id });
}

export function createPrintTrackingToken() {
    const bytes = crypto.getRandomValues(new Uint8Array(32));
    return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}

function invalidPrintInput() {
    return new ApiError(400, 'INVALID_PRINT_INPUT', 'Yazdırma isteği doğrulanamadı.');
}
